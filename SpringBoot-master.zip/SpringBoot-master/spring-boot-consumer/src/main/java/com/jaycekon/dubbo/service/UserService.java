package com.jaycekon.dubbo.service;

import com.jaycekon.dubbo.domain.User;

/**
 * Created by Jaycekon on 2017/9/19.
 */
public interface UserService {
    User saveUser(User user);
}
